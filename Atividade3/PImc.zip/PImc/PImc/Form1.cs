﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{

    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Valor Altura Inválido");
                mskbxAltura.Focus();
            }
            if (altura<= 0)
            {
                MessageBox.Show("Valor Peso Inválido");
                mskbxPeso.Focus();
            }
        }

        private void btnCalcular_Validated(object sender, EventArgs e)
        {
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            if (imc < 0)
                MessageBox.Show("Valores inválidos");
            else
                txtImc.Text = imc.ToString();

            if (imc < 18.5)
                txtClassificacao.Text = "Magreza";
            else
                if (imc < 24.9)
                txtClassificacao.Text = "Normal";
            else
                if (imc < 29.9)
                txtClassificacao.Text = "Sobrepeso";
            else
                if (imc < 39.9)
                txtClassificacao.Text = "Obesidade";
            else
                txtClassificacao.Text = "Obesidade Grave";

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
             mskbxPeso.Clear();
             mskbxAltura.Clear();
             txtImc.Clear();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Valor Peso Inválido");
                mskbxPeso.Focus();
            }
            if (peso <=0)
            {
                MessageBox.Show("Valor Peso Inválido");
                mskbxPeso.Focus();
            }
        }
    }
}
