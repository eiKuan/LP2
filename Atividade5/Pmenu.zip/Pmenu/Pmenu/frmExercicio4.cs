﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int i = 0,
                ContNum = 0,
                tamanho = rchtxtFrase.Text.Length;
            while (i < tamanho)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                    ContNum++;
                i++;
            }
            MessageBox.Show("A quantidade de numeros é: " + Convert.ToString(ContNum));
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i = 0, Posicao = 0;
            for (i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    // i+1 pois o usuario não tem a obrigação de saber que a primeira posição é reconhecida como 0 e caso não haja (posição = 0), conveniencia
                    Posicao = i + 1;
                    break;
                }
            }
            if (Posicao > 0)
                MessageBox.Show("A posição do primeiro espaço em branco é: " + Convert.ToString(Posicao));
            else
                MessageBox.Show("Não tem espaço em branco");


        }

        private void btnAlfa_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int alfa = 0;
            foreach(char letra in texto)
            {
                if (char.IsLetter(letra))
                    alfa += 1;
            }
            MessageBox.Show("O número de letras é :" + Convert.ToString(alfa));
        }
    }
}
