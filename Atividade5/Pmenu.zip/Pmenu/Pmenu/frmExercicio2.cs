﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            Convert.ToString(txtPalavra1.Text);
            Convert.ToString(txtPalavra2.Text);
            int resultado = string.Compare(txtPalavra2.Text, txtPalavra1.Text);
            if (resultado == 0)
            {
                MessageBox.Show("Palavras Iguais");
            }
            else
            {
                MessageBox.Show("Palavras Diferentes");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra2.Text.Length / 2;
            string palavra2 = txtPalavra2.Text, palavra1 = txtPalavra1.Text;
            string meiuca = palavra2.Substring(0, meio) + palavra1 + palavra2.Substring(meio);
            txtPalavra2.Text = meiuca;
        }
    }
}
