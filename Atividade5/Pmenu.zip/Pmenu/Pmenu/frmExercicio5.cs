﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Pmenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnAleatorio_Click(object sender, EventArgs e)
        {
            Random numeroRandom = new Random();
            int i=0, aleatorio;
            while (i < 2)
            {
                aleatorio = numeroRandom.Next();
                if (i == 0)
                    txtNumero1.Text = aleatorio.ToString();
                else
                    txtNumero2.Text = aleatorio.ToString();
                i++;
            }
            int verd1, verd2;
            bool eh = int.TryParse(txtNumero1.Text, out verd1);
            bool ih = int.TryParse(txtNumero2.Text, out verd2);
            if (eh && ih)
            {
                int numero1 = int.Parse(txtNumero1.Text);
                int numero2 = int.Parse(txtNumero2.Text);
                if (numero1 > numero2)
                {
                    MessageBox.Show("Numero 1 não é menor que Numero 2");
                }
                else
                {
                    MessageBox.Show("Numero 1 é menor que Numero 2");
                }
            }

            }
    }
}
