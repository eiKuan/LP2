﻿namespace PFilme02ok
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_exct = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.lst_bx_out = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_exct
            // 
            this.btn_exct.Location = new System.Drawing.Point(143, 84);
            this.btn_exct.Name = "btn_exct";
            this.btn_exct.Size = new System.Drawing.Size(132, 96);
            this.btn_exct.TabIndex = 0;
            this.btn_exct.Text = "Executar";
            this.btn_exct.UseVisualStyleBackColor = true;
            this.btn_exct.Click += new System.EventHandler(this.btn_exct_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(143, 242);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(132, 94);
            this.btn_clear.TabIndex = 1;
            this.btn_clear.Text = "Limpar";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // lst_bx_out
            // 
            this.lst_bx_out.FormattingEnabled = true;
            this.lst_bx_out.Location = new System.Drawing.Point(322, 70);
            this.lst_bx_out.Name = "lst_bx_out";
            this.lst_bx_out.Size = new System.Drawing.Size(368, 303);
            this.lst_bx_out.TabIndex = 2;
            this.lst_bx_out.SelectedIndexChanged += new System.EventHandler(this.lst_bx_out_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lst_bx_out);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_exct);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_exct;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.ListBox lst_bx_out;
    }
}

