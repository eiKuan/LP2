﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

namespace PFilme02ok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lst_bx_out_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_exct_Click(object sender, EventArgs e)
        {
            double[,] AVAL = new double[2, 2];
            string auxiliar;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do filme {j + 1}", $"Entrada de Dados pessoa { i + 1}");
                    if (string.IsNullOrEmpty(auxiliar))
                    {
                        MessageBox.Show("Erro, Digite algo");
                        j--;
                    }
                    else if (!double.TryParse(auxiliar, out AVAL[i, j]))
                        {
                            MessageBox.Show("Número Inválido");
                            j--;
                        }
                    else if (AVAL[i, j] < 0 || AVAL[i, j] > 10)
                    {
                        MessageBox.Show("Número Inválido");
                        j--;
                    }

                }
            }
                    string MD1;
                    string MD2;
                    MD1 = Convert.ToString((AVAL[0, 0] + AVAL[1, 0])/2);
                    MD2 = Convert.ToString((AVAL[0, 1] + AVAL[1, 1]) / 2);
         

            lst_bx_out.Items.Add($"Pessoa 1 Nota filme 1: {AVAL[0, 0]} ; Nota filme 2: {AVAL[0, 1]}");

            lst_bx_out.Items.Add($"Pessoa 2 Nota filme 1: {AVAL[1, 0]} ; Nota filme 2:  {AVAL[1, 1]}");

            lst_bx_out.Items.Add($"------------------------------------------");

            lst_bx_out.Items.Add($"Media Filme 1: {MD1}");

            lst_bx_out.Items.Add($"Media Filme 2: {MD2}");
            
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
         lst_bx_out.Items.Clear();
        }
    }
}
    
