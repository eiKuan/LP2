﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    internal class Mensalista : Empregado
    {
        public Double SalarioMensal { get; set; }

        public override double SalarioBruto() => SalarioMensal;


        public Mensalista()
        {
            MessageBox.Show("Passei por aqui");
        }
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
    }
}
