﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista();

            ObjMensalista.NomeEmpregado = txtNome.Text;
            ObjMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            ObjMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            ObjMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome=" + ObjMensalista.NomeEmpregado + "\n" + "Matrícula=" + ObjMensalista.Matricula + "\n" + "Tempo Trabalho:" + ObjMensalista.TempoTrabalho() + "\n"
                + "Salário Final=" + ObjMensalista.SalarioBruto().ToString("N2"));
        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMenstalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome=" + ObjMenstalista.NomeEmpregado + "\n" + "Matrícula=" + ObjMenstalista.Matricula + "\n" + "Tempo Trabalho:" + ObjMenstalista.TempoTrabalho() + "\n"
          + "Salário Final=" + ObjMenstalista.SalarioBruto().ToString("N2"));


        }
    }
}
