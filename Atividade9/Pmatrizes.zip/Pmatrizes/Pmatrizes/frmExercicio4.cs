﻿using Microsoft.VisualBasic;
using System;
using System.Linq;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string auxiliar = "";
            int[] caracter = new int[10];
            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o Nome {i + 1}", "Entrada de Dados");
                if (string.IsNullOrEmpty(auxiliar))
                {
                    MessageBox.Show("Erro, Digite algo");
                    i--;
                }
                else if (auxiliar.Count(char.IsLetter) == 0 || auxiliar.Count(char.IsDigit) > 0)
                {
                    MessageBox.Show("O nome precisa conter letras e não pode conter números");
                    i--;
                }
                else
                {
                    //int branco = auxiliar.Count(char.IsWhiteSpace);
                    caracter[i] = auxiliar.Count(char.IsLetter);
                    nomes[i] = auxiliar;
                }
            }
            for (var i = 0; i< 10; i++)
            {
                lbxNomes.Items.Add($"O nome {nomes[i]} contém {caracter[i]} caracteres");
            }
        }
    }
}
