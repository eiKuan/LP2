﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o Número {i + 1}", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";

            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thaís" };
            lista.Remove("Otávio");
            string aux = "";
            foreach (string s in lista)
            {
                aux += s + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string j = "", listaMedias = "";
            string[] med = new string[20];
            double[] media = new double[20];
            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    j = Interaction.InputBox($"Insira a nota {nota + 1} do aluno {aluno + 1}", $"Entrada de Dados");
                    if (!double.TryParse(j, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Não é número");
                        nota--;
                    }
                    else if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Número inválido, deve estar entre 0 e 10");
                        nota--;
                    }
                    else
                        media[aluno] += notas[aluno, nota];
                }
                med[aluno] = Convert.ToString(media[aluno] / 3.0);
                listaMedias += $"Média aluno {aluno + 1}:  " + med[aluno] + "\n";
            }
            MessageBox.Show(listaMedias);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmExercicio4 = new frmExercicio4();
            frmExercicio4.ShowDialog();

        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frmExercicio5 = new frmExercicio5();
            frmExercicio5.ShowDialog();
        }
    }
}
