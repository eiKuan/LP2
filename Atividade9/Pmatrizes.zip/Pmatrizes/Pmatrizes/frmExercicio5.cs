﻿using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, System.EventArgs e)
        {
            string[] gabarito = new string[10];
            string[,] respostas = new string[6, 10];
            string auxiliar;
            gabarito[0] =  "A";
            gabarito[1] =  "B";
            gabarito[2] =  "C";
            gabarito[3] =  "D";
            gabarito[4] =  "A";
            gabarito[5] =  "B";
            gabarito[6] =  "C";
            gabarito[7] =  "D";
            gabarito[8] =  "A";
            gabarito[9] =  "B";
            gabarito[10] = "C";

            for (int i = 0; i < 6; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta {j + 1}", "Entrada de Dados");
                    auxiliar = auxiliar.ToUpper();
                    if (auxiliar.Count(char.IsLetter) > 1)
                    {
                        MessageBox.Show("Informe somente uma letra");
                        j--;
                    }
                    else if(auxiliar != "A" || auxiliar != "B" || auxiliar != "C" || auxiliar != "D")
                    {
                        MessageBox.Show("A resposta deve ser a letra unica A, B, C, ou D");
                        j--;
                    }
                    else
                    {
                        respostas[i, j] = auxiliar;
                    }    
                }
            }
        }
    }
}
