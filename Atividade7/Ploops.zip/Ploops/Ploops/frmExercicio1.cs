﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int espaco = 0;
            for(int i = 0; i < rchtxtFrase.Text.Length; i++) {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                    espaco ++;
            }
            MessageBox.Show($"O número de espaços em brancos é: {espaco}");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int i = 0, r = 0;
            while(i < rchtxtFrase.Text.Length)
            {
                if (rchtxtFrase.Text[i] == 'r' || rchtxtFrase.Text[i] == 'R')
                    r++;
                i++;
            }
            MessageBox.Show($"O número de letras R é: {r}");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int i = 0, pares = 0;
            do
            {
                if (rchtxtFrase.Text.Length != 0)
                {
                    if (i == 0)
                    {
                        if ((rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1]))
                            pares++;
                    }
                    else if ((rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1]) && (rchtxtFrase.Text[i - 1] != rchtxtFrase.Text[i]))
                        pares++;
                    i++;
                }
                else
                {
                    MessageBox.Show("Texto inválido");
                    break;
                }
            } while (i < rchtxtFrase.Text.Length - 1);
            MessageBox.Show($"A quantidade de pares é: {pares}");
        }
    }
}
