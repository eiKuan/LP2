﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (lado1 < (lado2 + lado3) && lado1 > (Math.Abs(lado2 - lado3)) && lado2 < (lado1 + lado3) && lado2 > (Math.Abs(lado1 - lado3)) && lado3 > (Math.Abs(lado1 - lado2)) && lado3 < (lado1 + lado2))
            {
                if (lado1 == lado2 && lado1 == lado3)
                    txtResultado.Text = "Triângulo equilátero";
                else
                if (lado1 == lado2 || lado1 == lado3 || lado3 == lado2)
                    txtResultado.Text = "Triângulo Isósceles";
                else
                    txtResultado.Text = "Triângulo Escaleno";
            }
            else
                MessageBox.Show("Não forma um triângulo");

        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado2.Text, out lado2) || lado2 <= 0)
            {
                MessageBox.Show("Lado 2: Valor inválido");
                txtLado2.Focus();
            }
        }

        private void txtLado3_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado3.Text, out lado3) || lado3 <= 0)
            {
                MessageBox.Show("Lado 3: Valor inválido");
                txtLado3.Focus();
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
            txtResultado.Clear();
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out lado1) || lado1 <= 0)
            {
                MessageBox.Show("Lado 1: Valor inválido");
                txtLado1.Focus();
            }
        }
    }
}
